# ATSPass.ai
AI ATS resume analyzer: upload PDF/DOCX + job description → ATS score, skills match, keyword gaps, strengths/weaknesses, recommendations, and honest bullet rewrites.

**Stack:** Next.js 14 (App Router), React, TypeScript, Tailwind, pdf-parse, mammoth, Google Gemini API (free tier). No database; files are processed in memory.

## Run locally
```
npm install
copy .env.example .env.local   # then put your free key from https://aistudio.google.com/apikey
npm run dev
```
## Architecture
`app/page.tsx` landing → `components/Analyzer.tsx` (upload, JD, dashboard) → `POST /api/analyze` (validate, extract text, Gemini JSON analysis) and `POST /api/improve` (bullet rewrites). Server helpers in `lib/server.ts` (validation, extraction, Gemini call, rate limit 5/min/IP).
## API
- `POST /api/analyze` multipart: `file` (pdf/docx ≤5MB), `jd` (80–15000 chars) → `{analysis, resumeText}`; errors `{error}` with 400/422/429/502.
- `POST /api/improve` JSON `{bullets, resumeText, jd}` → `{bullets:[{original,improved}]}`.
## Deploy (Vercel)
Push to GitHub → vercel.com → Import repo → add env var `GEMINI_API_KEY` → Deploy.
