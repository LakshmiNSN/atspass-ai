import"./globals.css";
export const metadata={title:"ATSPass.ai – AI ATS Resume Analyzer",description:"Score your resume against any job description and fix gaps instantly."};
export default function L({children}:{children:React.ReactNode}){return<html lang="en"><head><meta name="viewport" content="width=device-width, initial-scale=1"/></head><body>{children}</body></html>}
