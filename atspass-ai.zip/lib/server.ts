import mammoth from "mammoth";
import pdf from "pdf-parse/lib/pdf-parse.js";
export class ApiError extends Error{constructor(public status:number,m:string){super(m)}}
const hits=new Map<string,number[]>();
export function rateLimit(ip:string){const n=Date.now(),a=(hits.get(ip)||[]).filter(t=>n-t<60000);if(a.length>=5)throw new ApiError(429,"Too many requests. Please wait a minute.");a.push(n);hits.set(ip,a)}
export async function extractText(file:File):Promise<string>{
 if(file.size>5*1024*1024)throw new ApiError(400,"File exceeds 5 MB.");
 const buf=Buffer.from(await file.arrayBuffer());const name=file.name.toLowerCase();let text="";
 try{
  if(name.endsWith(".pdf")&&buf.subarray(0,4).toString()==="%PDF")text=(await pdf(buf)).text;
  else if(name.endsWith(".docx")&&buf.subarray(0,2).toString()==="PK")text=(await mammoth.extractRawText({buffer:buf})).value;
  else throw new ApiError(400,"Only valid PDF or DOCX files are supported.");
 }catch(e){if(e instanceof ApiError)throw e;throw new ApiError(422,"Could not read this file. It may be corrupted or password-protected.")}
 text=text.replace(/\s+\n/g,"\n").trim();
 if(text.length<100)throw new ApiError(422,"Very little text found. Scanned/image-only resumes are not supported.");
 return text.slice(0,20000);
}
export async function gemini(prompt:string){
 const key=process.env.GEMINI_API_KEY;if(!key)throw new ApiError(500,"Server is missing GEMINI_API_KEY.");
 const model=process.env.GEMINI_MODEL||"gemini-2.5-flash";
 const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,{method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":key},body:JSON.stringify({contents:[{parts:[{text:prompt}]}],generationConfig:{responseMimeType:"application/json",temperature:0.2}})});
 if(!r.ok)throw new ApiError(502,r.status===429?"AI service is busy (free-tier limit). Try again shortly.":"AI service failed. Please try again.");
 try{const j=await r.json();return JSON.parse(j.candidates[0].content.parts[0].text)}catch{throw new ApiError(502,"AI returned an unreadable response. Please retry.")}
}
export const fail=(e:unknown)=>{const a=e instanceof ApiError?e:new ApiError(500,"Unexpected server error.");return Response.json({error:a.message},{status:a.status})};
